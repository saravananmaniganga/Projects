package week3.day1;

public abstract class PayTM implements RBI{
	
	public void aadharMandatory() {
		
	}
	
	public abstract void notifySMS();
	

}





