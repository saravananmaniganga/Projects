# RS-Component-Demo
Selenium BDD Test Automation

Project RS Component Demo:

This project is created for Selenium test automation framework for RS Componet.

Tools & libraries:

The test automation framework is comprised of following tools and libraries

*Cucumber-JVM:- BDD Framework
*Custom Page Object Pattern and utility functions
*Selenium WebDriver: - Browser automation framework *Selenium Grid: - Distribute test Execution across several machines
*JAVA: - Programming language
*TestNg: - TestNg Java testing framework
*Maven: - Build tool
*Jenkins: - Continuous Integration
*Git OR SVN: - Version Control
*Github or Local Git Server: - Git repository hosted server
*Intellij Or Eclipse: - Integrated Development Environment


