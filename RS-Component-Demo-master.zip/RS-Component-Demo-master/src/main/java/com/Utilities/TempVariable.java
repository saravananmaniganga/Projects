package com.Utilities;

public class TempVariable {

    public String userName;
    public String rsStockNO;

    public void setRsStockNO(String rsStockNO) {
        this.rsStockNO = rsStockNO;
    }


    public void setUserName(String userName) {
        this.userName = userName;
    }


}
